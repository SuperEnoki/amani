<?php

function bekento_taxonomy_edit_meta_field($term) {

	// Getting colors from theme
	$bekento_colors_available = '';
	$bekento_category_color = '';
	if(function_exists(get_template().'_api_color_scheme')) {
		$colors = call_user_func(get_template().'_api_color_scheme');
		if(is_array($colors)) {
			$bekento_colors_available = esc_html__('Current color scheme:', 'bekento').' ';
			$bekento_category_color = $colors[array_rand($colors)];
			foreach ($colors as $value) {
				$bekento_colors_available .= '<code style="background-color: '.$value.'; color: #fff;">'.$value.'</code>';
			}
		}
	}

	if(isset($term->term_id)) {
		$t_id = $term->term_id;
		// retrieve the existing value(s) for this meta field. This returns an array
		$term_meta = get_option("taxonomy_".$t_id);
		// Checking if set
		if($term_meta['bekento_category_color']) {
			$bekento_category_color = $term_meta['bekento_category_color'];
		} else {
			// Not set, trying transient
			$bekento_category_color = get_transient('bekento_category_color_'.$t_id.'');
		}
	}


	?>
	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[bekento_category_color]"><?php esc_html_e('Category Color', 'bekento'); ?></label></th>
		<td>
			<input type="color" name="term_meta[bekento_category_color]" id="term_meta[bekento_category_color]" style="width: 45px; height: 30px;" value="<?php echo $bekento_category_color; ?>"/> <?php echo $bekento_colors_available; ?>
			<br/><br/>
		</td>
	</tr>
<?php
}
add_action('category_edit_form_fields', 'bekento_taxonomy_edit_meta_field', 10, 2);
add_action('category_add_form_fields', 'bekento_taxonomy_edit_meta_field', 10, 2);

// CATEGORY: Saving

add_action('edited_category', 'bekento_save_taxonomy_custom_meta', 10, 2);
add_action('create_category', 'bekento_save_taxonomy_custom_meta', 10, 2);

function bekento_save_taxonomy_custom_meta($term_id) {
	if(isset($_POST['term_meta'])) {
		$t_id = $term_id;
		$term_meta = get_option("taxonomy_".$t_id);
		$cat_keys = array_keys($_POST['term_meta']);
		foreach ($cat_keys as $key) {
			if (isset($_POST['term_meta'][$key])) {
				$term_meta[$key] = $_POST['term_meta'][$key];
			}
		}
		// Save the option array.
		update_option('taxonomy_'.$t_id, $term_meta);
	}
}

// CATEGORY: Get Option

function bekento_category_color($t_id) {
	$cat_data = get_option("taxonomy_".$t_id);
	$option = '';
	if(isset($cat_data['bekento_category_color'])) {
		$option = $cat_data['bekento_category_color'];
	} else {
		// Get Temporary color from transient
		$category_color_transient = get_transient('bekento_category_color_'.$t_id.'');
		if($category_color_transient) {
			// Transient set
			$option = $category_color_transient;
		} else {
			// New Installation Setting Transient
			if(function_exists(get_template().'_api_color_scheme')) {
				$colors = call_user_func(get_template().'_api_color_scheme');
				if(is_array($colors)) {
					set_transient('bekento_category_color_'.$t_id.'', $colors[array_rand($colors)]);
				}
			}
		}
	}
	return esc_attr($option);
}

// Clearing temporary category colors

function bekento_clear_transient() {
	global $wpdb;
	$sql = 'DELETE FROM '.$wpdb->options.' WHERE option_name LIKE "_transient_bekento_category_color_%"';
	$wpdb->query($sql);
}
add_action('customize_save_after', 'bekento_clear_transient');

